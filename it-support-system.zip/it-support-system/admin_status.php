<?php
include 'db.php';

$status = "Offline";

$result = $conn->query(
    "SELECT is_online FROM admin_status WHERE is_online = 1 LIMIT 1"
);

if($result && $result->num_rows > 0){
    $status = "Online";
}

echo $status;
