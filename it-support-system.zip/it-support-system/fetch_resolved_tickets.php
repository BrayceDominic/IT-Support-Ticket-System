<?php
session_start();
include 'db.php';

if(!isset($_SESSION['user_id'])){
    header("Location: login.html");
    exit();
}

$id = $_SESSION['user_id'];

$result = $conn->query("
    SELECT ticket_number, title, description, estimated_time, instructions, created_at
    FROM tickets
    WHERE status='Resolved' && user_id=$id
    ORDER BY created_at DESC
");

$tickets = [];

while($row = $result->fetch_assoc()){
    $tickets[] = $row;
}

echo json_encode($tickets);
