<?php
include '../db.php';

if(isset($_POST['full_name'],$_POST['email'],$_POST['password'])){
    $name = $_POST['full_name'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $stmt = $conn->prepare("INSERT INTO users (full_name,email,password) VALUES (?,?,?)");
    $stmt->bind_param("sss",$name,$email,$password);

    if($stmt->execute()){
        echo json_encode(['success'=>true]);
    } else {
        echo json_encode(['error'=>'Email already exists']);
    }
}
