<?php
session_start();
include '../db.php';

if(isset($_SESSION['admin_id'])){
    $admin_id = $_SESSION['admin_id'];
    $conn->query("UPDATE admin_status SET is_online=0 WHERE admin_id=$admin_id");
}

session_destroy();
header("Location: admin_login.php");
