<?php
include '../db.php';


$result = $conn->query("
    SELECT ticket_number, title, description, estimated_time, instructions, created_at
    FROM tickets
    WHERE status='Resolved'
    ORDER BY created_at DESC
");

$tickets = [];

while($row = $result->fetch_assoc()){
    $tickets[] = $row;
}

echo json_encode($tickets);
