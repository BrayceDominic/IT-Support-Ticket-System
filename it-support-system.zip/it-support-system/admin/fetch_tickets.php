<?php
session_start();
include '../db.php';

if(!isset($_SESSION['admin_id'])){
    die("Unauthorized");
}

$result = $conn->query("SELECT * FROM tickets ORDER BY created_at DESC");
$tickets = [];

while($row = $result->fetch_assoc()){
    $tickets[] = $row;
}

echo json_encode($tickets);
