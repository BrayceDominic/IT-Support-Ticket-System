<?php
session_start();
if(!isset($_SESSION['admin_id'])){
    header("Location: admin_login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Admin Dashboard</title>

<!-- Google Font -->
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<!-- Ionicons -->
<script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>

<style>
:root{
  --bg:#020617;
  --glass:rgba(255,255,255,.12);
  --blur:blur(18px);
  --primary:#6366f1;
  --success:#22c55e;
  --warning:#f59e0b;
  --danger:#ef4444;
}

*{box-sizing:border-box}

body{
  margin:0;
  font-family:Garamond,serif;
  background:linear-gradient(135deg,#020617,#0f172a);
  color:#fff;
}

/* ================= HEADER ================= */
header{
  display:flex;
  justify-content:space-between;
  align-items:center;
  padding:20px 30px;
  background:var(--glass);
  backdrop-filter:var(--blur);
  box-shadow:0 10px 30px rgba(0,0,0,.4);
}

header h1{
  font-size:20px;
  font-weight:600;
  display:flex;
  align-items:center;
  gap:10px;
}

.logout{
  text-decoration:none;
  color:#fff;
  background:rgba(239,68,68,.2);
  padding:10px 16px;
  border-radius:12px;
  transition:.3s;
}

.logout:hover{
  background:var(--danger);
}

/* ================= CONTAINER ================= */
.container{
  padding:30px;
  max-width:1100px;
  margin:auto;
}

/* ================= TICKET CARD ================= */
.ticket{
  background:var(--glass);
  backdrop-filter:var(--blur);
  border-radius:20px;
  padding:24px;
  margin-bottom:24px;
  box-shadow:0 25px 60px rgba(0,0,0,.45);
  animation:fadeUp .6s ease;
}

.ticket h3{
  margin:0 0 6px;
  font-size:18px;
}

.ticket p{
  opacity:.9;
  font-size:14px;
}

/* ================= STATUS BADGE ================= */
.badge{
  display:inline-block;
  padding:6px 14px;
  border-radius:999px;
  font-size:12px;
  font-weight:600;
  margin:10px 0;
}

.pending{background:rgba(245,158,11,.2);color:var(--warning)}
.confirmed{background:rgba(99,102,241,.2);color:var(--primary)}
.resolved{background:rgba(34,197,94,.2);color:var(--success)}

/* ================= FORM ================= */
.grid{
  display:grid;
  grid-template-columns:1fr 1fr;
  gap:14px;
  margin-top:15px;
}

input,select,textarea{
  width:100%;
  padding:12px 14px;
  border-radius:12px;
  border:none;
  outline:none;
  background:rgba(255,255,255,.15);
  color:#fff;
  font-size:13px;
  font-family: Garamond,serif;
}

textarea{grid-column:1/3}

input::placeholder,textarea::placeholder{
  color:#cbd5e1;
}

select{
  grid-column:1/3;
}

/* ================= BUTTON ================= */
button{
  margin-top:15px;
  width:100%;
  padding:14px;
  border-radius:14px;
  border:none;
  background:linear-gradient(135deg,var(--primary),#06b6d4);
  color:#fff;
  font-weight:600;
  cursor:pointer;
  transition:.35s;
  font-family: Garamond,serif;
}

button:hover{
  transform:translateY(-2px);
  box-shadow:0 15px 40px rgba(99,102,241,.5);
}

/* ================= ANIMATIONS ================= */
@keyframes fadeUp{
  from{opacity:0;transform:translateY(15px)}
  to{opacity:1;transform:translateY(0)}
}

@media(max-width:768px){
  .grid{grid-template-columns:1fr}
  textarea,select{grid-column:1}
}

.inbox-item{
  padding:12px;
  border-radius:12px;
  margin-bottom:10px;
  cursor:pointer;
  background:rgba(255,255,255,.1);
  transition:.3s;
}
.inbox-item:hover{
  background:rgba(255,255,255,.2);
  transform:translateX(3px);
}
.viewer-ticket{
  background:var(--glass);
  backdrop-filter:var(--blur);
  border-radius:16px;
  padding:20px;
  margin-bottom:20px;
  animation:fadeUp .4s ease;
}
.viewer-ticket p{margin:8px 0;}

</style>
</head>

<body>

<header>
  <h1><ion-icon name="shield-checkmark-outline"></ion-icon> IT Support Admin</h1>
  <a href="admin_logout.php" class="logout">
    <ion-icon name="log-out-outline"></ion-icon> Logout
  </a>
</header>

<div class="container" style="display:flex; gap:20px; flex-wrap:wrap;">

  <!-- Left Sidebar: Resolved Tickets -->
  <div style="flex:1; min-width:250px; max-height:600px; overflow-y:auto; background:rgba(255,255,255,.05); padding:15px; border-radius:16px;">
    <h3><ion-icon name="mail-open-outline"></ion-icon> Resolved Tickets</h3>
    <div id="resolved-list">Loading...</div>
  </div>

  <!-- Right Panel: Ticket Editor -->
  <div style="flex:2; min-width:300px; max-height:600px; overflow-y:auto;" id="ticket-panel">
    <h3>Select a ticket to edit</h3>
  </div>

</div>


<script>
function loadTickets(){
  fetch('fetch_tickets.php')
  .then(res=>res.json())
  .then(data=>{
    let html="";
    data.forEach(t=>{
      let badgeClass = t.status==="Pending"?"pending":t.status==="Confirmed"?"confirmed":"resolved";
      html+=`
      <div class="ticket">
        <h3>${t.title}</h3>
        <p>${t.description}</p>

        <span class="badge ${badgeClass}">
          ${t.status}
        </span>

        <div class="grid">
          <select id="status-${t.id}">
            <option ${t.status=="Pending"?"selected":""}>Pending</option>
            <option ${t.status=="Confirmed"?"selected":""}>Confirmed</option>
            <option ${t.status=="Resolved"?"selected":""}>Resolved</option>
          </select>

          <input id="eta-${t.id}" placeholder="Estimated Time">
          <textarea id="inst-${t.id}" placeholder="Instructions for the user"></textarea>
        </div>

        <button onclick="updateTicket(${t.id})">
          <ion-icon name="save-outline"></ion-icon> Update Ticket
        </button>
      </div>`;
    });
    document.getElementById("ticket-container").innerHTML = html;
  });
}

function updateTicket(id){
  let data = new URLSearchParams();
  data.append("id",id);
  data.append("status",document.getElementById("status-"+id).value);
  data.append("estimated_time",document.getElementById("eta-"+id).value);
  data.append("instructions",document.getElementById("inst-"+id).value);

  fetch('update_ticket.php',{method:'POST',body:data})
  .then(()=>loadTickets());
}

loadTickets();
setInterval(loadTickets,180000);

function loadTickets(){
  fetch('fetch_tickets.php')
  .then(res=>res.json())
  .then(data=>{
    const panel = document.getElementById("ticket-panel");
    let html = "";

    data.forEach(t=>{
      html += `
      <div class="viewer-ticket">
        <h3>${t.title}</h3>
        <p>${t.description}</p>
        <span class="badge ${t.status==="Pending"?"pending":t.status==="Confirmed"?"confirmed":"resolved"}">${t.status}</span>
        <div class="grid">
          <select id="status-${t.id}">
            <option ${t.status=="Pending"?"selected":""}>Pending</option>
            <option ${t.status=="Confirmed"?"selected":""}>Confirmed</option>
            <option ${t.status=="Resolved"?"selected":""}>Resolved</option>
          </select>
          <input id="eta-${t.id}" placeholder="Estimated Time" value="${t.estimated_time||''}">
          <textarea id="inst-${t.id}" placeholder="Instructions for the user">${t.instructions||''}</textarea>
        </div>
        <button onclick="updateTicket(${t.id})"><ion-icon name="save-outline"></ion-icon> Update Ticket</button>
      </div>
      `;
    });
    panel.innerHTML = html;
  });
}

function loadResolvedTickets(){
  fetch('fetch_resolved_tickets.php')
  .then(r=>r.json())
  .then(data=>{
    const list = document.getElementById("resolved-list");
    list.innerHTML = "";
    if(data.length===0){
      list.innerHTML="<p>No resolved tickets</p>";
      return;
    }
    data.forEach(t=>{
      const div = document.createElement("div");
      div.className="inbox-item";
      div.innerHTML = `<b>${t.title}</b><br><small>${new Date(t.created_at).toLocaleDateString()}</small>`;
      div.onclick=()=>openResolvedTicket(t);
      list.appendChild(div);
    });
  });
}

function openResolvedTicket(ticket){
  const panel = document.getElementById("ticket-panel");
  panel.innerHTML = `
    <div class="viewer-ticket">
      <h3>${ticket.title}</h3>
      <p><b>Ticket #:</b> ${ticket.ticket_number}</p>
      <p><b>Description:</b><br>${ticket.description}</p>
      <p><b>Instructions:</b><br>${ticket.instructions||'N/A'}</p>
      <p><b>Estimated Time:</b> ${ticket.estimated_time||'N/A'}</p>
      <span class="badge resolved">Resolved</span>
    </div>
  `;
}

function updateTicket(id){
  let data = new URLSearchParams();
  data.append("id",id);
  data.append("status",document.getElementById("status-"+id).value);
  data.append("estimated_time",document.getElementById("eta-"+id).value);
  data.append("instructions",document.getElementById("inst-"+id).value);

  fetch('update_ticket.php',{method:'POST',body:data})
  .then(()=>{loadTickets(); loadResolvedTickets();});
}

// INITIAL LOAD
loadTickets();
loadResolvedTickets();
setInterval(()=>{loadTickets(); loadResolvedTickets();},180000); // refresh every 3 min

</script>

</body>
</html>
