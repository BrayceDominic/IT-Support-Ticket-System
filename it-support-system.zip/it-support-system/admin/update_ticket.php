<?php
session_start();
include '../db.php';

if(!isset($_SESSION['admin_id'])){
    die("Unauthorized");
}

$id = $_POST['id'];
$status = $_POST['status'];
$eta = $_POST['estimated_time'];
$instructions = $_POST['instructions'];

$stmt = $conn->prepare(
    "UPDATE tickets SET status=?, estimated_time=?, instructions=? WHERE id=?"
);
$stmt->bind_param("sssi",$status,$eta,$instructions,$id);
$stmt->execute();

echo json_encode(['success'=>true]);
