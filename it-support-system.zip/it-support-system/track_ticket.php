<?php
include 'db.php';

if(isset($_GET['ticket_number'])){
    $ticket_number = $_GET['ticket_number'];

    $stmt = $conn->prepare("SELECT title, description, status, estimated_time, instructions FROM tickets WHERE ticket_number=?");
    $stmt->bind_param("s", $ticket_number);
    $stmt->execute();
    $result = $stmt->get_result();

    if($result->num_rows > 0){
        $ticket = $result->fetch_assoc();
        echo json_encode($ticket);
    } else {
        echo json_encode(['error'=>'Ticket not found']);
    }
}
?>
