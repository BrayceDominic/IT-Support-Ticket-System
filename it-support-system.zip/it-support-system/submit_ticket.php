<?php
// Start session to get logged in user
session_start();
include 'db.php';

if(!isset($_SESSION['user_id'])){
    die(json_encode(['error'=>'Please login first']));
}

if(isset($_POST['title'], $_POST['description'])){
    $user_id = $_SESSION['user_id'];
    $title = $_POST['title'];
    $description = $_POST['description'];

    // Generate a unique ticket number
    $ticket_number = 'TICK'.date('Ymd').'-'.rand(100,999);

    // Insert ticket into database
    $stmt = $conn->prepare("INSERT INTO tickets (user_id, title, description, ticket_number) VALUES (?,?,?,?)");
    $stmt->bind_param("isss", $user_id, $title, $description, $ticket_number);
    $stmt->execute();

    echo json_encode(['success'=>true, 'ticket_number'=>$ticket_number]);
} else {
    echo json_encode(['error'=>'Missing fields']);
}
?>
